import requests
import json
import os
import time



path = r"G:\数据\atls\样本图片\pati"

images = [file for file in os.listdir(path)]

path = "/home/HwHiAiUser/ljx_test/pati"
for image in images:
    image = os.path.join(path, image)
    image = image.replace("\\", "/")
    print(image)
    url = "http://192.168.1.249:9999/api/ImageInference"
    data = {
        "sysCode": "1",
        "eqpNo": "test_image",
        "ruleNo": "xxxx",
        "dataType": "2",
        "rawPic": f"{image}",
        "recognize": [{
            "para": [{
                "type": "helmet_detect",
                "conf_thresh": 0.8
            },
                {
                "type": "pedestrian_detect",
                "conf_thresh": 0.7
            },
                {
                "type": "climbing_detect",
                "conf_thresh": 0.7
            },
                {
                "type": "fence_detect",
                "conf_thresh": 0.7
            },
                {
                "type": "pedestrian_under_crane",
                "conf_thresh": 0.7
            },
                {
                "type": "hang_rail_detect",
                "conf_thresh": 0.7
            },
                {
                "type": "hook_detect",
                "conf_thresh": 0.7
            },
                {
                "type": "fire_detect",
                "conf_thresh": 0.7
            },
                {
                "type": "hole_detect",
                "conf_thresh": 0.7
            },
                {
                "type": "safety_beltDetect",
                "conf_thresh": 0.7
            },
                {
                "type": "sleeve_detect",
                "conf_thresh": 0.7
            }
            ]
        }],
        "reportInfoType": "101",
        "resultUrl": "192.168.1.51:8080"
    }
    time.sleep(1)
    res = requests.post(url, data=json.dumps(data))
    print(res.json())
